===========================================================
 SOFTWARE
===========================================================
GetSimple CMS is a flatfile CMS package that works 
fast and efficient and has the best UI around.
Official Website - http://get-simple.info/

GetSimple CMS was developed by Chris Cagle at 
Cagintranet Web Design - http://www.cagintranet.com/, but  
now passionately supported and developed by a lovely community.



===========================================================
 LICENSE
===========================================================
This software package is licensed under the GNU GENERAL 
PUBLIC LICENSE. It is as open as open-source can be.

Please view the license at http://www.gnu.org/licenses/gpl-3.0.txt

I just ask that you link back to our site if you use it.



===========================================================
 REQUIREMENTS
===========================================================
Hosting Server Requirements:
 - PHP 5.1.3+    			http://www.gophp5.org/
	(i) 		SimpleXML		(All files are saved as XML)
	(ii.) 	SMTP Server	(for Reset Password Option)
	(iii.) 	mod_write		(for url creeation)

Administrator's Browser/Computer Requirements:
 - Flash 8 Installed		(File Uploads)
 - Javascript Enabled		(Will make life much easier)



===========================================================
 INSTALL & UPGRADE PROCEDURE
===========================================================
http://get-simple.info/docs/installation



===========================================================
 DISCLAIMER
===========================================================
While GetSimple strives to be a secure and stable application, 
we simply cannot be held liable for any information loss,
corruption or anything else that may happen to your site while 
it is using the our software. If you find a bug or security 
hole, please contact someone in the forums at 
http://get-simple.info/forum



-----------------------------------------------------------
<end>