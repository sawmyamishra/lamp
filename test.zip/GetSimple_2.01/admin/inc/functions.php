<?php
/****************************************************
*
* @File: 	functions.php
* @Package:	GetSimple
* @Action:	Initialize needed functions for cp. 	
*
*****************************************************/

# discontinued as of version 2.0

?>